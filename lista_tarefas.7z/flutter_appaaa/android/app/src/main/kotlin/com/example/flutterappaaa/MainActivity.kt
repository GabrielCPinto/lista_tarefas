package com.example.flutterappaaa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
